config_opts['root'] = 'mageia-{{ releasever }}-{{ target_arch }}'
config_opts['chroot_setup_cmd'] = 'install basesystem-minimal-core rpm-build rpm-mageia-setup rpm-mageia-setup-build'
config_opts['dist'] = 'mga{{ releasever }}'  # only useful for --resultdir variable subst
config_opts['extra_chroot_dirs'] = [ '/run/lock', ]
config_opts['macros']['%distro_section'] = 'core'
config_opts['package_manager'] = 'dnf'
config_opts['bootstrap_image'] = 'docker.io/library/mageia:{{ releasever }}'
config_opts['use_bootstrap_image'] = False
config_opts['description'] = 'Mageia {{ releasever }}'

config_opts['dnf.conf'] = """
[main]
keepcache=1
debuglevel=2
reposdir=/dev/null
logfile=/var/log/yum.log
retries=20
obsoletes=1
gpgcheck=0
assumeyes=1
syslog_ident=mock
syslog_device=
install_weak_deps=0
metadata_expire=0
best=1
protected_packages=
user_agent={{ user_agent }}

# repos

[mageia]
name=Mageia $releasever - {{ repo_arch }}
#baseurl=http://mirrors.kernel.org/mageia/distrib/$releasever/{{ repo_arch }}/media/core/release/
#metalink=https://mirrors.mageia.org/metalink?distrib=mageia-$releasever&arch={{ repo_arch }}@&section=core&repo=release
mirrorlist=https://www.mageia.org/mirrorlist/?release=$releasever&arch={{ repo_arch }}&section=core&repo=release
fastestmirror=1
gpgcheck=1
gpgkey=file:///usr/share/distribution-gpg-keys/mageia/RPM-GPG-KEY-Mageia
enabled=1
skip_if_unavailable=False

[updates]
name=Mageia $releasever - {{ repo_arch }} - Updates
#baseurl=http://mirrors.kernel.org/mageia/distrib/$releasever/{{ repo_arch }}/media/core/updates/
#metalink=https://mirrors.mageia.org/metalink?distrib=mageia-$releasever&arch={{ repo_arch }}@&section=core&repo=updates
mirrorlist=https://www.mageia.org/mirrorlist/?release=$releasever&arch={{ repo_arch }}&section=core&repo=updates
fastestmirror=1
gpgcheck=1
gpgkey=file:///usr/share/distribution-gpg-keys/mageia/RPM-GPG-KEY-Mageia
enabled=1
skip_if_unavailable=False

[mageia-debuginfo]
name=Mageia $releasever - {{ repo_arch }} - Debug
#baseurl=http://mirrors.kernel.org/mageia/distrib/$releasever/{{ repo_arch }}/media/debug/core/release/
#metalink=https://mirrors.mageia.org/metalink?distrib=mageia-$releasever&arch={{ repo_arch }}@&section=core&repo=release&debug=true
mirrorlist=https://www.mageia.org/mirrorlist/?release=$releasever&arch={{ repo_arch }}&section=core&repo=release&debug=1
fastestmirror=1
gpgcheck=1
gpgkey=file:///usr/share/distribution-gpg-keys/mageia/RPM-GPG-KEY-Mageia
enabled=0
skip_if_unavailable=False

[updates-debuginfo]
name=Mageia $releasever - {{ repo_arch }} - Updates - Debug
#baseurl=http://mirrors.kernel.org/mageia/distrib/$releasever/{{ repo_arch }}/media/debug/core/updates/
#metalink=https://mirrors.mageia.org/metalink?distrib=mageia-$releasever&arch={{ repo_arch }}@&section=core&repo=updates&debug=true
mirrorlist=https://www.mageia.org/mirrorlist/?release=$releasever&arch={{ repo_arch }}&section=core&repo=updates&debug=1
fastestmirror=1
gpgcheck=1
gpgkey=file:///usr/share/distribution-gpg-keys/mageia/RPM-GPG-KEY-Mageia
enabled=0
skip_if_unavailable=False
"""
